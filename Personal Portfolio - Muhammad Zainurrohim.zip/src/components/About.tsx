import { Target, TrendingUp, Users, Lightbulb } from 'lucide-react';

export function About() {
  const highlights = [
    {
      icon: Target,
      title: 'Strategic Planning',
      description: 'Developing comprehensive business strategies aligned with organizational goals',
    },
    {
      icon: TrendingUp,
      title: 'Market Analysis',
      description: 'In-depth market research and competitive intelligence gathering',
    },
    {
      icon: Users,
      title: 'Partnership Development',
      description: 'Building and nurturing strategic partnerships for mutual growth',
    },
    {
      icon: Lightbulb,
      title: 'Innovation Focus',
      description: 'Identifying emerging trends and opportunities for business expansion',
    },
  ];

  return (
    <section id="about" className="py-20 px-4 sm:px-6 lg:px-8 bg-gray-50">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <div className="text-blue-600 mb-4">About Me</div>
          <h2 className="text-gray-900 mb-4">Transforming Research into Results</h2>
          <p className="text-gray-600 max-w-3xl mx-auto">
            With a passion for uncovering insights and driving growth, I combine analytical rigor 
            with strategic thinking to help organizations expand their market presence and achieve 
            sustainable competitive advantages.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {highlights.map((highlight, index) => (
            <div key={index} className="bg-white p-6 rounded-xl shadow-sm hover:shadow-md transition-shadow">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                <highlight.icon className="text-blue-600" size={24} />
              </div>
              <h3 className="text-gray-900 mb-2">{highlight.title}</h3>
              <p className="text-gray-600">{highlight.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
