import { BarChart3, Database, Globe, PieChart, FileSearch, Handshake } from 'lucide-react';

export function Skills() {
  const skillCategories = [
    {
      category: 'Research & Analysis',
      icon: FileSearch,
      skills: [
        { name: 'Market Research', level: 95 },
        { name: 'Competitive Analysis', level: 90 },
        { name: 'Data Analytics', level: 85 },
        { name: 'Trend Forecasting', level: 88 },
      ],
    },
    {
      category: 'Business Development',
      icon: Handshake,
      skills: [
        { name: 'Strategic Planning', level: 92 },
        { name: 'Partnership Management', level: 90 },
        { name: 'Stakeholder Engagement', level: 88 },
        { name: 'Negotiation', level: 85 },
      ],
    },
    {
      category: 'Tools & Technologies',
      icon: BarChart3,
      skills: [
        { name: 'Excel & Data Visualization', level: 90 },
        { name: 'CRM Systems', level: 85 },
        { name: 'SQL & Databases', level: 80 },
        { name: 'Business Intelligence Tools', level: 82 },
      ],
    },
  ];

  return (
    <section id="skills" className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <div className="text-blue-600 mb-4">Skills & Expertise</div>
          <h2 className="text-gray-900 mb-4">Core Competencies</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            A diverse skill set combining research methodology, business acumen, and technical proficiency
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {skillCategories.map((category, index) => (
            <div key={index} className="bg-white p-6 rounded-xl border border-gray-200">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                  <category.icon className="text-blue-600" size={20} />
                </div>
                <h3 className="text-gray-900">{category.category}</h3>
              </div>
              <div className="space-y-4">
                {category.skills.map((skill, skillIndex) => (
                  <div key={skillIndex}>
                    <div className="flex justify-between mb-2">
                      <span className="text-gray-700">{skill.name}</span>
                      <span className="text-gray-500">{skill.level}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div
                        className="bg-blue-600 h-2 rounded-full transition-all duration-500"
                        style={{ width: `${skill.level}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
