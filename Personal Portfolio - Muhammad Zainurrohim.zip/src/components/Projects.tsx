import { ExternalLink, TrendingUp, Globe, Users, Building } from 'lucide-react';

export function Projects() {
  const projects = [
    {
      title: 'Global Market Expansion Strategy',
      category: 'Market Research',
      icon: Globe,
      description: 'Comprehensive research and strategy development for entering three new international markets, resulting in successful market entry and 35% year-over-year growth.',
      tags: ['Market Analysis', 'Strategic Planning', 'International Business'],
      impact: '35% YoY Growth',
    },
    {
      title: 'Strategic Partnership Framework',
      category: 'Business Development',
      icon: Users,
      description: 'Designed and implemented a partnership evaluation and management framework that streamlined the partnership process and improved success rates by 50%.',
      tags: ['Partnership Management', 'Process Optimization', 'Stakeholder Management'],
      impact: '50% Success Rate Improvement',
    },
    {
      title: 'Competitive Intelligence Platform',
      category: 'Research & Analytics',
      icon: TrendingUp,
      description: 'Built an automated competitive intelligence system aggregating data from multiple sources, providing real-time insights for strategic decision-making.',
      tags: ['Data Analytics', 'Automation', 'Business Intelligence'],
      impact: '60% Time Savings',
    },
    {
      title: 'Industry Vertical Analysis',
      category: 'Market Research',
      icon: Building,
      description: 'Led comprehensive analysis of emerging technology sectors, identifying $10M+ in revenue opportunities and informing product development roadmap.',
      tags: ['Market Research', 'Trend Analysis', 'Revenue Generation'],
      impact: '$10M+ Opportunities Identified',
    },
  ];

  return (
    <section id="projects" className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <div className="text-blue-600 mb-4">Projects & Case Studies</div>
          <h2 className="text-gray-900 mb-4">Featured Work</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Highlighting key projects that demonstrate strategic impact and measurable results
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {projects.map((project, index) => (
            <div
              key={index}
              className="bg-white rounded-xl border border-gray-200 p-6 hover:shadow-lg transition-shadow group"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center group-hover:bg-blue-600 transition-colors">
                  <project.icon className="text-blue-600 group-hover:text-white transition-colors" size={24} />
                </div>
                <span className="text-blue-600 bg-blue-50 px-3 py-1 rounded-full">
                  {project.category}
                </span>
              </div>
              
              <h3 className="text-gray-900 mb-3">{project.title}</h3>
              <p className="text-gray-600 mb-4">{project.description}</p>
              
              <div className="flex flex-wrap gap-2 mb-4">
                {project.tags.map((tag, tagIndex) => (
                  <span
                    key={tagIndex}
                    className="bg-gray-100 text-gray-700 px-3 py-1 rounded-md"
                  >
                    {tag}
                  </span>
                ))}
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-gray-200">
                <div className="flex items-center gap-2 text-green-600">
                  <TrendingUp size={18} />
                  <span>{project.impact}</span>
                </div>
                <button className="text-blue-600 hover:text-blue-700 flex items-center gap-1">
                  View Details <ExternalLink size={16} />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
