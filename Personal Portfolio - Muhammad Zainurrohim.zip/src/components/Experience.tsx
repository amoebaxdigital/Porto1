import { Briefcase, Calendar } from 'lucide-react';

export function Experience() {
  const experiences = [
    {
      title: 'Senior Business Development Manager',
      company: 'TechGrowth Solutions',
      period: '2021 - Present',
      description: 'Leading strategic initiatives to expand market presence in emerging sectors. Developed partnerships resulting in 40% revenue growth.',
      achievements: [
        'Secured 15+ strategic partnerships with key industry players',
        'Led market research initiatives across 8 new markets',
        'Implemented data-driven decision framework adopted company-wide',
      ],
    },
    {
      title: 'Research & Strategy Analyst',
      company: 'GlobalMarket Insights',
      period: '2018 - 2021',
      description: 'Conducted comprehensive market research and competitive analysis to inform strategic business decisions.',
      achievements: [
        'Delivered 50+ market research reports for Fortune 500 clients',
        'Identified growth opportunities generating $5M+ in new revenue',
        'Built automated data collection systems improving efficiency by 60%',
      ],
    },
    {
      title: 'Business Development Associate',
      company: 'Innovation Partners Inc.',
      period: '2016 - 2018',
      description: 'Supported business development initiatives through research, analysis, and stakeholder engagement.',
      achievements: [
        'Contributed to acquisition of 20+ new client accounts',
        'Developed competitive intelligence database used across teams',
        'Assisted in preparation of strategic proposals with 75% success rate',
      ],
    },
  ];

  return (
    <section id="experience" className="py-20 px-4 sm:px-6 lg:px-8 bg-gray-50">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <div className="text-blue-600 mb-4">Experience</div>
          <h2 className="text-gray-900 mb-4">Professional Journey</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            A track record of driving growth and delivering insights across diverse industries
          </p>
        </div>

        <div className="max-w-4xl mx-auto space-y-8">
          {experiences.map((exp, index) => (
            <div key={index} className="bg-white p-6 md:p-8 rounded-xl shadow-sm">
              <div className="flex flex-col md:flex-row md:items-start md:justify-between mb-4">
                <div>
                  <h3 className="text-gray-900 mb-2">{exp.title}</h3>
                  <div className="flex items-center gap-2 text-blue-600 mb-2">
                    <Briefcase size={18} />
                    <span>{exp.company}</span>
                  </div>
                </div>
                <div className="flex items-center gap-2 text-gray-500">
                  <Calendar size={18} />
                  <span>{exp.period}</span>
                </div>
              </div>
              <p className="text-gray-600 mb-4">{exp.description}</p>
              <div className="space-y-2">
                <div className="text-gray-700">Key Achievements:</div>
                <ul className="space-y-2">
                  {exp.achievements.map((achievement, achIndex) => (
                    <li key={achIndex} className="flex items-start gap-2 text-gray-600">
                      <span className="text-blue-600 mt-1">•</span>
                      <span>{achievement}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
