import { ArrowRight, Linkedin, Mail, FileText } from 'lucide-react';

export function Hero() {
  return (
    <section id="home" className="pt-32 pb-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <div className="text-blue-600 mb-4">Hello, I'm</div>
            <h1 className="text-gray-900 mb-4">Alex Morgan</h1>
            <h2 className="text-gray-700 mb-6">Business Development & Research Professional</h2>
            <p className="text-gray-600 mb-8 max-w-lg">
              Driving strategic growth through data-driven insights and innovative market research. 
              Specialized in identifying opportunities, building partnerships, and transforming research into actionable business strategies.
            </p>
            <div className="flex flex-wrap gap-4 mb-8">
              <a
                href="#contact"
                className="inline-flex items-center gap-2 bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors"
              >
                Get in Touch <ArrowRight size={20} />
              </a>
              <a
                href="#projects"
                className="inline-flex items-center gap-2 border-2 border-gray-300 text-gray-700 px-6 py-3 rounded-lg hover:border-blue-600 hover:text-blue-600 transition-colors"
              >
                View Projects
              </a>
            </div>
            <div className="flex gap-4">
              <a href="#" className="text-gray-600 hover:text-blue-600 transition-colors">
                <Linkedin size={24} />
              </a>
              <a href="#contact" className="text-gray-600 hover:text-blue-600 transition-colors">
                <Mail size={24} />
              </a>
              <a href="#" className="text-gray-600 hover:text-blue-600 transition-colors">
                <FileText size={24} />
              </a>
            </div>
          </div>
          <div className="relative">
            <div className="aspect-square rounded-2xl bg-gradient-to-br from-blue-100 to-blue-200 flex items-center justify-center">
              <div className="text-center">
                <div className="text-blue-600 text-6xl mb-4">📊</div>
                <div className="text-gray-600">Business Development</div>
                <div className="text-gray-600">& Research</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
